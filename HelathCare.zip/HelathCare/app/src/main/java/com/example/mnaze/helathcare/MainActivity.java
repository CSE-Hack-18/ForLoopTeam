package com.example.mnaze.helathcare;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import cn.iwgang.countdownview.CountdownView;

public class MainActivity extends AppCompatActivity {
    Dialog myPopUp;
    private ViewPager viewPager;
    private SlideAdapter mAdapt;
    private DrawerLayout mDraw;
    private ActionBarDrawerToggle mTBar;
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myPopUp = new Dialog(this);
        mDraw = (DrawerLayout) findViewById(R.id.drawer);
        mTBar = new ActionBarDrawerToggle(this, mDraw,R.string.open,R.string.close);
        mDraw.addDrawerListener(mTBar);
        mTBar.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        CountdownView mCvCountdownView = (CountdownView)findViewById(R.id.cv_countdownViewTest1);
        mCvCountdownView.start(995550000); // Millisecond
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mTBar.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void DisplayPopUp(View v){
        TextView txtclose;
        Button btnoperation;
        myPopUp.setContentView(R.layout.notifippop);
        txtclose = (TextView) myPopUp.findViewById(R.id.txtclose);
        btnoperation = (Button) myPopUp.findViewById(R.id.btnoperation);
        txtclose.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                myPopUp.dismiss();
            }
        });
        myPopUp.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myPopUp.show();

    }

    public void openNewAc(){
        Intent intent = new Intent(this,Slides2.class);
        startActivity(intent);

    }
}

