package com.demotxt.droidsrce.slide;


import android.content.Context;
import android.graphics.Color;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SlideAdapter extends PagerAdapter {
    Context context;
    LayoutInflater inflater;

    // list of images
    public int[] lst_images = {
            R.drawable.wishlist,
            R.drawable.image_5,
            R.drawable.image_6,
            R.drawable.image_7,
            R.drawable.image_8,

            R.drawable.surgery6,
            R.drawable.surgery5,
            R.drawable.t,
            R.drawable.image_2,
            R.drawable.image_3,
            R.drawable.image_4
    };
    // list of titles
    public String[] lst_title = {
            "Fill in entry form",
            "Name",
            "Personal number",
            "Relationship status",
            "Allergies",
            "Surgery",
            "You have heart surgery on 2018-05-16",
            "NO Fast Food",
            "No Aspirin",
            "No Insulin",
            "No Sugar"
    }   ;
    // list of descriptions
    public String[] lst_description = {
            "________ ",
            "What's your full name?",
            "What is your swedish personal number?",
            "Are you married?",
            "List the name of products/ medicines that you are allergic to",

            "________ ",
            "Prepare yourself",
            "Please avoid all fast food in this period",
            "Don't take any aspirin before 10 hour before the surgery",
            "Don't take any insulin injections before 5 hour before the surgery ",
            "Don't eat sugar one week before the surgery "
    };
    // list of background colors
    public int[]  lst_backgroundcolor = {
            Color.rgb(153, 153, 102),
            Color.rgb(55,55,55),
            Color.rgb(204, 102, 255),
            Color.rgb(102, 153, 153),
            Color.rgb(110,49,89),

            Color.rgb(255,255,255),
            Color.rgb(55,55,55),
            Color.rgb(204, 102, 255),
            Color.rgb(239,85,85),
            Color.rgb(102, 153, 0),
            Color.rgb(1,188,212)
    };


    public SlideAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return lst_title.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return (view==(LinearLayout)object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.slide,container,false);
        LinearLayout layoutslide = (LinearLayout) view.findViewById(R.id.slidelinearlayout);
        ImageView imgslide = (ImageView)  view.findViewById(R.id.slideimg);
        TextView txttitle= (TextView) view.findViewById(R.id.txttitle);
        TextView description = (TextView) view.findViewById(R.id.txtdescription);
        layoutslide.setBackgroundColor(lst_backgroundcolor[position]);
        imgslide.setImageResource(lst_images[position]);
        txttitle.setText(lst_title[position]);
        description.setText(lst_description[position]);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout)object);
    }
}
